<?php


echo @file_get_contents('index.html.bak.bak');
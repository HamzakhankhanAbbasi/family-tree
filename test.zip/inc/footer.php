

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/popper-min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/stellarnav.min.js"></script>
<script src="assets/js/aos.js"></script>
<script src="assets/js/custom.js"></script>
<script>
	AOS.init();
</script>
        <div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header border-bottom-0">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="form-title text-center">
                  <h4>Forgot Password</h4>
                </div>
                <div class="d-flex modal-btn flex-column text-center">
                  <form>
                    <div class="form-group email">
                      <span class="form-icon icon-hov"><i class="fas fa-envelope"></i></span>    
                      <input type="email" class="form-inp" id="email1"placeholder="Enter Your email address...">
                    </div>
                    <button type="button" class="login-btn">Login</button>
                  </form>
              </div>
            </div>
          </div>
          </div>
        </div>  
</body>
</html>